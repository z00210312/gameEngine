#include "gameWindow.h"
#define WaitPullMode 0;

gameWindow::gameWindow(const char *title, int &width, int &height)
{
	// window variables
	m_title = title;
	m_width = width;
	m_height = height;
	
	// openGL variables
	init();
	glClearColor(0.5, 0.5f, 0.5, 1.0f);
	glfwPollEvents();
	glfwSwapBuffers(m_window);
	
	// game variables
	newState = loading;
	
	FLOAT_0 = 0.0f;
	lastTime = 0.0;
	CurrentSpritesLocation_x = 0.0f;
	CurrentSpritesLocation_y = 0.0f;
	light_pos_z = -1.0f;

	testScaleValue = 1.0f;
	testDegree = 0.0f;
	spritePtr = nullptr;
	PrevSpritePtr = nullptr;

	// GLSL
	m_colorProgram.init("Shader/newShader.vert", "Shader/newShader.frag", "Shader/newShader.attr");
	setMainSceneTexture();
	setPlaySceneTexture();
	setInventoryTexture();
	// set crusor
	GLubyte newColor[4] = { 255,255,255,255 };
	float floatCrusor[8] = { 0.0f, 0.0f, 0.1f, 0.1f, (float)3 / 8, (float)2 / 8, (float)4 / 8, (float)3 / 8 };
	newCrusor.init(floatCrusor[0], floatCrusor[1], floatCrusor[2], floatCrusor[3], floatCrusor[4], floatCrusor[5], floatCrusor[6], floatCrusor[7], newColor);

	// set player
	playerTexture.setPNGTextureID("Shader/CharacterLeft_Standing.png");
	float newFloats[8] = { 0.0f ,0.0f, 0.2f, 0.2f, FLOAT_0, FLOAT_0, 1.0f, 1.0f};
	newPlayer.init(newFloats[0], newFloats[1], newFloats[2], newFloats[3], newFloats[4], newFloats[5], newFloats[6], newFloats[7], newColor);

	newItem.init(floatCrusor[0], floatCrusor[1], floatCrusor[2], floatCrusor[3], newFloats[4], newFloats[5], newFloats[6], newFloats[7], newColor);
	newItem_rightLocation = false;
	newItem.active = false;
	// finish loading 
	newState = mainScene;

	//////////// extra ////////////

	//glfwSetCursor(m_window, 0);
	//glfwSetInputMode(m_window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
	//newTexture.setDDSTextureID("test.dds");
}


gameWindow::~gameWindow()
{
	glfwDestroyWindow(m_window);
	glfwTerminate();
}

bool gameWindow::init()
{
	if (!glfwInit()) {
		std::cout << "GLFW error" << std::endl;
		return false;
	}
	glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);
	m_window = glfwCreateWindow(m_width, m_height, m_title, NULL, NULL);
	if (!m_window) {
		std::cout << "window error" << std::endl;
		return false;
	}

	glfwMakeContextCurrent(m_window);
	glfwSetWindowPos(m_window, 100, 100);

	if (glewInit() != GLEW_OK) {
		std::cout << "GLEW error" << std::endl;
		return false;
	}

	initKeys();
	initCallbacks();

	return true;
}

void gameWindow::initKeys()
{
	for (bool i : m_key)
		i = false;
	for (bool j : m_mouseButton)
		j = false;
}

void gameWindow::initCallbacks()
{
	glfwSetWindowUserPointer(m_window, this);
	glfwSetKeyCallback(m_window, key_callback);
	glfwSetMouseButtonCallback(m_window, mouse_button_callback);
	glfwSetCursorPosCallback(m_window, cursor_position_callback);
	glfwSetWindowSizeCallback(m_window, resize_callback);
}

void gameWindow::gameLoop()
{
	m_colorProgram.enable();
	m_colorProgram.OrthoMatrix((float)-m_width / m_height, (float)m_width / m_height, -1.0f, 1.0f, -3.0f, 3.0f);
	m_colorProgram.ScaleMatrix(glm::vec3(testScaleValue, testScaleValue, testScaleValue));
	m_colorProgram.RotateMatrix(0.0f, 0.0f, 0.0f, 1.0f);
	m_colorProgram.initColorAndEffect(1.0f, 1.0f, 1.0f, 1.0f, 0.0000001f, 0.0000001f, light_pos_z);
	m_colorProgram.disable();

	while (!gameClose()) {
		time = glfwGetTime();
		deltaTime = time - lastTime;
		if (deltaTime >= maxPeriod) {
			lastTime = time;
			gameClear();
			gameUpdate();
		}
	}
}

void gameWindow::gameClear()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

void gameWindow::gameUpdate()
{

#if WaitPullMode

	glfwWaitEvents();
#else
	glfwPollEvents();
#endif
	/*
	if (isMouseButtonPressed(GLFW_MOUSE_BUTTON_LEFT)) {
		//std::cout << m_cursor_xpos << " : " << m_cursor_ypos << std::endl;
		//std::cout <<((m_cursor_xpos - (m_width / 2)) / m_width) << " : " << ((-m_cursor_ypos + (m_height / 2)) / m_height) << std::endl;
		mainScene = true;
		playScene = false;
	}

	if (isMouseButtonPressed(GLFW_MOUSE_BUTTON_RIGHT)) {
		mainScene = false;
		playScene = true;
	}
	*/
	if (newState == mainScene) {
		getMainScene();
		
	}
	else if (newState == playScene) {
		PlaySceneKeyEvnts();
		getPlayScene();
	}
	else if (newState == inventoryScene) {
		getInventory();
		if (isMouseButtonPressed(GLFW_MOUSE_BUTTON_RIGHT)) {
			if (newItem.active) {
				newItem_rightLocation = false;
				newItemLocX = getWindowMousePosx();
				newItemLocY = getWindowMousePosy();
			}

			for (int i = 0; i < newSlots.getInventorySize(); i++) {
				if (newSlots.getInventoryPtr()[i]->active) {
					if (newSlots.getInventoryPtr()[i]->isCollision(getWindowMousePosx(), getWindowMousePosy(), 0.0f, 0.0f)) {
						newItemLocX = newSlots.getInventoryPtr()[i]->getPosx() + newItem.getPosWidth() / 2;
						newItemLocY = newSlots.getInventoryPtr()[i]->getPosy() + newItem.getPosHeight() / 2;
						newItem_rightLocation = true;
						spritePtr = newSlots.getInventoryPtr()[i];
					}
				}
			}
			/*
			for (std::vector<spriteObj>::iterator it = newSlots.getInvetoryIterBegin(); it != newSlots.getInvetoryIterEnd(); ++it) {
				if (it->active) {
					if (it->isCollision(getWindowMousePosx(), getWindowMousePosy(), 0.0f, 0.0f)) {
						//it->active = false;
						newItemLocX = it->getPosx() + newItem.getPosWidth() / 2;
						newItemLocY = it->getPosy() + newItem.getPosHeight() / 2;
						newItem_rightLocation = true;
						spritePtr = it->getThis();
					}
				}
			}
			*/
		}
	}
	//spriteCrusor();
	glfwSwapBuffers(m_window);
}

bool gameWindow::isKeyPressed(unsigned int key) const
{
	if (key>KEY_MAX)
		return false;
	return m_key[key];
}

bool gameWindow::isMouseButtonPressed(unsigned int button) const
{
	if (button>MOUSE_BUTTON_MAX)
		return false;
	return m_mouseButton[button];
}

void gameWindow::key_callback(GLFWwindow * window, int key, int scancode, int action, int mods)
{
	gameWindow* win = (gameWindow*)glfwGetWindowUserPointer(window);
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GLFW_TRUE);
	win->m_key[key] = action != GLFW_RELEASE;
}

void gameWindow::mouse_button_callback(GLFWwindow * window, int button, int action, int mods)
{
	gameWindow* win = (gameWindow*)glfwGetWindowUserPointer(window);
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
		switch (win->newState) {
		case playScene:
			win->newState = inventoryScene;
			break;
		case mainScene:
			win->newState = playScene;
			break;
		case loading:
			win->CurrentSpritesLocation_x = 0.0f;
			win->CurrentSpritesLocation_y = 0.0f;
			win->newState = mainScene;
			break;
		case inventoryScene:
			win->newState = mainScene;
			break;
		default:
			break;
		}
	}
	if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS) {
		//win->newState = loading;
		if (win->newItem.isCollision(
			win->getWindowMousePosx() - win->newItemLocX + win->newItem.getPosWidth() / 2, 
			win->getWindowMousePosy() - win->newItemLocY + win->newItem.getPosHeight() / 2, 
			win->newItem.getPosWidth(), 
			win->newItem.getPosHeight())) 
		{
			win->newItem.active = true;
			if (win->PrevSpritePtr != nullptr) {
				win->PrevSpritePtr->active = true;
			}
		}
	}
	if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_RELEASE) {
		win->newItem.active = false;
		if (!win->newItem_rightLocation) {
			if (win->PrevSpritePtr != nullptr) {
				win->newItemLocX = win->PrevSpritePtr->getPosx() + win->newItem.getPosWidth() / 2;
				win->newItemLocY = win->PrevSpritePtr->getPosy() + win->newItem.getPosHeight() / 2;
			}
			else {
				win->newItemLocX = 0.0f;
				win->newItemLocY = 0.0f;
			}
			
		}
		else if (win->newItem_rightLocation) {
			win->spritePtr->active = false;
			win->PrevSpritePtr = win->spritePtr;
			win->spritePtr = nullptr;
			//win->spritePtr = nullptr;
		}
	}
		
	win->m_mouseButton[button] = action != GLFW_RELEASE;
}

void gameWindow::cursor_position_callback(GLFWwindow * window, double xpos, double ypos)
{
	gameWindow* win = (gameWindow*)glfwGetWindowUserPointer(window);
	win->m_cursor_xpos = (float)xpos;
	win->m_cursor_ypos = (float)ypos;
}

void gameWindow::resize_callback(GLFWwindow * window, int width, int height)
{
	gameWindow* win = (gameWindow*)glfwGetWindowUserPointer(window);
	glViewport(0, 0, width, height);
	win->m_width = width;
	win->m_height = height;
}

void gameWindow::PlaySceneKeyEvnts()
{
	if (isKeyPressed(GLFW_KEY_A)) {
		if (!newTexture.isCollision(newPlayer.getPosx() + CurrentSpritesLocation_x - 0.05f, newPlayer.getPosy() + CurrentSpritesLocation_y, newPlayer.getPosWidth(), newPlayer.getPosHeight())) {
			//std::cout << "KEY_Q Pressed" << std::endl;
			CurrentSpritesLocation_x -= 0.05f;
		}
	}
	if (isKeyPressed(GLFW_KEY_D)) {

		if (!newTexture.isCollision(newPlayer.getPosx() + CurrentSpritesLocation_x + 0.05f, newPlayer.getPosy() + CurrentSpritesLocation_y, newPlayer.getPosWidth(), newPlayer.getPosHeight())) {
			CurrentSpritesLocation_x += 0.05f;
		}
	}
	if (isKeyPressed(GLFW_KEY_W)) {
		if (!newTexture.isCollision(newPlayer.getPosx() + CurrentSpritesLocation_x, newPlayer.getPosy() + CurrentSpritesLocation_y + 0.05f, newPlayer.getPosWidth(), newPlayer.getPosHeight())) {
			CurrentSpritesLocation_y += 0.05f;
		}
	}

	if (isKeyPressed(GLFW_KEY_S)) {
		if (!newTexture.isCollision(newPlayer.getPosx() + CurrentSpritesLocation_x, newPlayer.getPosy() + CurrentSpritesLocation_y - 0.05f, newPlayer.getPosWidth(), newPlayer.getPosHeight())) {
			CurrentSpritesLocation_y -= 0.05f;
		}
	}

	if (isKeyPressed(GLFW_KEY_PERIOD)) {
		//std::cout << testDegree << std::endl;
		testDegree += 0.1f;
	}

	if (isKeyPressed(GLFW_KEY_COMMA)) {
		//std::cout << testDegree << std::endl;
		testDegree -= 0.1f;
	}

	if (isKeyPressed(GLFW_KEY_R)) {
		testDegree = 0.0f;
		light_pos_z = 1.0f;
		CurrentSpritesLocation_x = 0.0f;
		CurrentSpritesLocation_y = 0.0f;
	}

	if (isKeyPressed(GLFW_KEY_F)) {
	}
	
	if (isKeyPressed(GLFW_KEY_Z)) {
		light_pos_z++;
	}

	if (isKeyPressed(GLFW_KEY_C)) {
		light_pos_z--;
	}

	if (isKeyPressed(GLFW_KEY_X)) {
	}
}

void gameWindow::spriteCrusor()
{
	////////// crusor //////////
	////////////////////////////

	m_colorProgram.enable();
	//m_colorProgram.OrthoMatrix((float)-m_width / m_height, (float)m_width / m_height, -1.0f, 1.0f, -3.0f, 3.0f);
	m_colorProgram.TranslateMatrix(-0.5f*(2.0f * newCrusor.getPosx() + newCrusor.getPosWidth()) + getWindowMousePosx(), -0.5f*(2.0f * newCrusor.getPosy() + newCrusor.getPosHeight()) + getWindowMousePosy(), 0.0f);
	m_colorProgram.initColorAndEffect(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
	//m_colorProgram.RotateMatrix(0.0f, 0.0f, 0.0f, 1.0f);

	newTexture.enable(m_colorProgram.getUniformLocation("sampler_1"));
	newCrusor.draw();
	newTexture.disable();

	m_colorProgram.disable();

	////////////////////////////
	/////////// end ////////////
}

void gameWindow::spritePlayer()
{
	/////// First Person ///////
	////////////////////////////

	m_colorProgram.enable();
	//m_colorProgram.OrthoMatrix((float)-m_width / m_height, (float)m_width / m_height, -1.0f, 1.0f, -3.0f, 3.0f);
	m_colorProgram.TranslateMatrix(-0.5f*(2.0f * newPlayer.getPosx() + newPlayer.getPosWidth()), -0.5f*(2.0f * newPlayer.getPosy() + newPlayer.getPosHeight()), 0.0f);
	//m_colorProgram.RotateMatrix(0.0f, 0.0f, 0.0f, 1.0f);

	playerTexture.enable(m_colorProgram.getUniformLocation("sampler_1"));
	newPlayer.draw();
	playerTexture.disable();

	m_colorProgram.disable();

	////////////////////////////
	/////////// end ////////////
}

void gameWindow::setMainSceneTexture()
{
	backgroundTexture.setPNGTextureID("Shader/sky/Daylight Box_0.png");
	/*
	float temp_x = -m_width / m_height;
	float temp_y = -1.0f;
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 3; j++) {
			backgroundTexture.addNewSprite(temp_x, temp_y, m_width / m_height, 1.0f, (float)(i) / 4, (float)(2 - j) / 3, (float)(i + 1) / 4, (float)(3 - j) / 3);
			temp_y += 1.0f;
		}
		temp_x += (m_width / m_height);
		temp_y = -1.0f;
	}
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 3; j++) {
			backgroundTexture.addNewSprite(temp_x, temp_y, m_width / m_height, 1.0f, (float)(i) / 4, (float)(2 - j) / 3, (float)(i + 1) / 4, (float)(3 - j) / 3);
			temp_y += 1.0f;
		}
		temp_x += (m_width / m_height);
		temp_y = -1.0f;
	}
	*/
	backgroundTexture.addNewSprite(0.0f, 0.0f, 4.0f * 2.0f * (float)m_width / m_height / testScaleValue, 2.0f * (float)m_height / m_height / testScaleValue, 0.0f, 0.0f, 3.0f, 1.0f);
}

void gameWindow::setPlaySceneTexture()
{
	newTexture.setPNGTextureID("dungeon.png");
	newTexture.addNewSprite(0.5f, 0.5f, 0.1f, 0.1f, 0.0f, (float)2 / 8, (float)1 / 8, (float)3 / 8);
	newTexture.addNewSprite(0.6f, 0.5f, 0.1f, 0.1f, (float)1 / 8, (float)2 / 8, (float)2 / 8, (float)3 / 8);
	newTexture.addNewSprite(0.7f, 0.5f, 0.1f, 0.1f, (float)2 / 8, (float)2 / 8, (float)3 / 8, (float)3 / 8);

	newTexture.addNewSprite(0.5f, 0.6f, 0.1f, 0.1f, 0.0f, (float)1 / 8, (float)1 / 8, (float)2 / 8);
	newTexture.addNewSprite(0.6f, 0.6f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(0.7f, 0.6f, 0.1f, 0.1f, (float)2 / 8, (float)1 / 8, (float)3 / 8, (float)2 / 8);

	newTexture.addNewSprite(0.5f, 0.7f, 0.1f, 0.1f, 0.0f, 0.0f, (float)1 / 8, (float)1 / 8);
	newTexture.addNewSprite(0.6f, 0.7f, 0.1f, 0.1f, (float)1 / 8, 0.0f, (float)2 / 8, (float)1 / 8);
	newTexture.addNewSprite(0.7f, 0.7f, 0.1f, 0.1f, (float)2 / 8, 0.0f, (float)3 / 8, (float)1 / 8);

	newTexture.addNewSprite(0.2f, 0.5f, 0.3f, 0.3f, 0.0f, 0.0f, (float)3 / 8, (float)3 / 8);

	newTexture.addNewSprite(0.6f, 0.0f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(0.6f, -0.3f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(0.6f, -0.6f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(0.6f, -0.9f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(1.2f, -0.9f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(1.5f, -0.9f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(1.8f, -0.9f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(2.1f, -0.9f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(2.4f, -0.9f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(1.8f, -1.2f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(1.8f, -1.5f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(1.8f, -1.8f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(1.8f, -2.1f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(1.8f, -2.4f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(1.8f, -2.7f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
	newTexture.addNewSprite(1.8f, 0.0f, 0.1f, 0.1f, (float)1 / 8, (float)1 / 8, (float)2 / 8, (float)2 / 8);
}

void gameWindow::setInventoryTexture()
{
	newSlots.init("Shader/BlankSpot.png", "Shader/border.png", m_width, m_height);
	newSlots.setInventory(6, 4);

	/*
	inventoryTexture.setPNGTextureID("Shader/BlankSpot.png");
	float temp_x = m_width / m_height -0.5f;
	float temp_y = 0.4f;
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 6; j++) {
			inventoryTexture.addNewSprite(temp_x, temp_y, 0.1f, 0.1f, 0.0f, 0.0f, 1.0f, 1.0f);
			temp_x += 0.1f;
		}
		temp_x = m_width / m_height - 0.5f;
		temp_y -= 0.1f;
	}



	

	borderTexture.setPNGTextureID("Shader/border.png");
	for (int j = 0; j < 6; j++) {
		borderTexture.addNewSprite(temp_x, temp_y, 0.1f, 0.1f, (float)1 / 3, (float)1 / 3, (float)2 / 3, (float)2 / 3);
		temp_x += 0.1f;
	}



	temp_x = m_width / m_height - 0.6f;
	temp_y = 0.5f;

	borderTexture.addNewSprite(temp_x, temp_y, 0.1f, 0.1f, 0.0f, 0.0f, (float)1 / 3, (float)1 / 3);
	temp_x += 0.1f;

	for (int i = 0; i < 6; i++) {
		borderTexture.addNewSprite(temp_x, temp_y, 0.1f, 0.1f, (float)1 / 3, 0.0f, (float)2 / 3, (float)1 / 3);
		temp_x += 0.1f;
	}

	borderTexture.addNewSprite(temp_x, temp_y, 0.1f, 0.1f, (float)2 / 3, 0.0f, 1.0f, (float)1 / 3);
	//temp_x = m_width / m_height - 0.6f;
	temp_y -= 0.1f;
	for (int i = 0; i < 5; i++) {
		borderTexture.addNewSprite(temp_x, temp_y, 0.1f, 0.1f, (float)2 / 3, (float)1 / 3, (float)3 / 3, (float)2 / 3);
		temp_y -= 0.1f;
	}
	borderTexture.addNewSprite(temp_x, temp_y, 0.1f, 0.1f, (float)2 / 3, (float)2 / 3, (float)3 / 3, (float)3 / 3);
	temp_x -= 0.1f;
	for (int i = 0; i < 6; i++) {
		borderTexture.addNewSprite(temp_x, temp_y, 0.1f, 0.1f, (float)1 / 3, (float)2 / 3, (float)2 / 3, (float)3 / 3);
		temp_x -= 0.1f;
	}
	borderTexture.addNewSprite(temp_x, temp_y, 0.1f, 0.1f, (float)0 / 3, (float)2 / 3, (float)1 / 3, (float)3 / 3);
	temp_y += 0.1f;
	for (int i = 0; i < 5; i++) {
		borderTexture.addNewSprite(temp_x, temp_y, 0.1f, 0.1f, (float)0 / 3, (float)1 / 3, (float)1 / 3, (float)2 / 3);
		temp_y += 0.1f;
	}
	*/
}

float gameWindow::getWindowMousePosx()
{
	return (1.0f / testScaleValue) * ((m_cursor_xpos - (m_width / 2.0f)) / m_width) * 2.0f * m_width / m_height;
}

float gameWindow::getWindowMousePosy()
{
	return (1.0f / testScaleValue) * ((-m_cursor_ypos + (m_height / 2.0f)) / m_height) * 2.0f * m_height / m_height;
}

void gameWindow::getMainScene()
{
	m_colorProgram.enable();
	//m_colorProgram.TranslateMatrix((float)-m_width/m_height - std::fmod(time,4.0f), -1.0f, 0.0f);
	m_colorProgram.TranslateMatrix((float)-m_width / m_height - std::fmod(time, 8.0f) / 2, -1.0f, 0.0f);
	m_colorProgram.initColorAndEffect(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f);
	m_colorProgram.disable();
	for (std::vector<spriteObj>::iterator it = backgroundTexture.getSpriteBegin(); it != backgroundTexture.getSpriteEnd(); ++it) {
		m_colorProgram.enable();

		backgroundTexture.enable(m_colorProgram.getUniformLocation("sampler_1"));
		it->draw();

		m_colorProgram.disable();
	}
}

void gameWindow::getPlayScene()
{
	for (std::vector<spriteObj>::iterator it = newTexture.getSpriteBegin(); it != newTexture.getSpriteEnd(); ++it) {
		m_colorProgram.enable();
		//m_colorProgram.OrthoMatrix((float)-m_width / m_height, (float)m_width / m_height, -1.0f, 1.0f, -3.0f, 3.0f);
		//m_colorProgram.ScaleMatrix(glm::vec3(testScaleValue, testScaleValue, testScaleValue));
		//m_colorProgram.TranslateMatrix(testXTranslate, testYTranslate, 0.0f);
		m_colorProgram.TranslateMatrix(-CurrentSpritesLocation_x - 0.5f*(2.0f * newPlayer.getPosx() + newPlayer.getPosWidth()), -CurrentSpritesLocation_y - 0.5f*(2.0f * newPlayer.getPosy() + newPlayer.getPosHeight()), 0.0f);
		//m_colorProgram.RotateMatrix(0.0f, 0.0f, 0.0f, 1.0f);
		m_colorProgram.initColorAndEffect(1.0f, 1.0f, 1.0f, 1.0f, 0.0000001f, 0.0000001f, light_pos_z);
		newTexture.enable(m_colorProgram.getUniformLocation("sampler_1"));
		it->draw();
		newTexture.disable();
		//m_colorProgram.initColorAndEffect(1.0f, 1.0f, 1.0f, 1.0f, 0.5*( 2*newSpriteObj.getPosx() + newSpriteObj.getPosWidth()), 0.5*(2*newSpriteObj.getPosy() + newSpriteObj.getPosHeight()), light_pos_z);
		m_colorProgram.disable();
	}
	spritePlayer();
}

void gameWindow::getInventory()
{
	newSlots.displayInventory(m_colorProgram);
	m_colorProgram.enable();
	//m_colorProgram.OrthoMatrix((float)-m_width / m_height, (float)m_width / m_height, -1.0f, 1.0f, -3.0f, 3.0f);
	m_colorProgram.TranslateMatrix(newItemLocX - newItem.getPosWidth() / 2, newItemLocY - newItem.getPosHeight() / 2, 0.0f);
	//m_colorProgram.RotateMatrix(0.0f, 0.0f, 0.0f, 1.0f);

	playerTexture.enable(m_colorProgram.getUniformLocation("sampler_1"));
	newItem.draw();
	playerTexture.disable();
	m_colorProgram.disable();
}